import boto3
import json

def lambda_handler(event, context):
    comprehend_client = boto3.client('comprehend')
    
    text = event['text']
    
    # Detect the dominant sentiment
    sentiment_response = comprehend_client.detect_sentiment(Text=text, LanguageCode='en')
    sentiment = sentiment_response['Sentiment']
    
    # Manually map basic sentiments and text content to more specific emotions
    emotion = map_sentiment_to_emotion(sentiment, text)
    
    return {
        'statusCode': 200,
        'body': json.dumps({"Emotion": emotion})
    }

def map_sentiment_to_emotion(sentiment, text):
    # Define keywords for additional emotions
    emotion_keywords = {
        'EXCITED': ['excited', 'thrilled', 'can\'t wait'],
        'SURPRISED': ['surprised', 'unexpected', 'astonished'],
        'CRYING': ['crying', 'tears', 'sobbing'],
        'HAPPY': ['happy', 'joy', 'pleased'],
        'SAD': ['sad', 'unhappy', 'sorrow'],
        'ANGRY': ['angry', 'mad', 'furious'],
    }

    # Default emotion based on sentiment
    default_emotions = {
        'POSITIVE': 'HAPPY',
        'NEGATIVE': 'SAD',
        'NEUTRAL': 'NEUTRAL',
        'MIXED': 'CONFUSED'
    }
    
    # Check for specific keywords to determine emotion
    for emotion, keywords in emotion_keywords.items():
        if any(keyword in text.lower() for keyword in keywords):
            return emotion

    # Return default emotion if no keywords match
    return default_emotions.get(sentiment, 'NEUTRAL')

