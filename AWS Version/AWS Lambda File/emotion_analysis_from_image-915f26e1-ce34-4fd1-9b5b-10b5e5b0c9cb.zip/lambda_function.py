import json
import boto3
import base64
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)

def lambda_handler(event, context):
    rekognition = boto3.client('rekognition')

    # Check if the image key exists in the event
    if 'image' not in event:
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Image data is missing'})
        }

    # Decode the base64-encoded image
    try:
        image_bytes = base64.b64decode(event['image'])
    except base64.binascii.Error as e:
        logger.error(f"Base64 decoding failed: {str(e)}")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Base64 decoding failed'})
        }

    # Call Rekognition to detect faces
    try:
        response = rekognition.detect_faces(
            Image={'Bytes': image_bytes},
            Attributes=['ALL']
        )
    except rekognition.exceptions.InvalidImageFormatException as e:
        logger.error(f"Invalid image format: {str(e)}")
        return {
            'statusCode': 400,
            'body': json.dumps({'error': 'Invalid image format'})
        }

    # Process the Rekognition response
    emotions = response['FaceDetails'][0]['Emotions'] if response['FaceDetails'] else []
    top_emotion = max(emotions, key=lambda x: x['Confidence']) if emotions else None

    return {
        'statusCode': 200,
        'body': json.dumps({
            'emotion': top_emotion['Type'] if top_emotion else 'No face detected'
        })
    }
