import boto3
import json

def lambda_handler(event, context):
    # Initialize the Bedrock client
    bedrock = boto3.client(service_name='bedrock-runtime')
    
    # Extract the emotion from the Lambda function's input event
    emotion = event.get('emotion', 'happy')  # Default to 'happy' if not provided
    
    # Construct the prompt with the input emotion
    body = json.dumps({
        "prompt": f"\n\nHuman:You are a music recommendation system that suggests Bollywood songs based on emotions. Suggest songs matching the given emotion in input is {emotion}, e.g., sad songs for sadness or energetic songs for happiness.\n\nAssistant:",
        "max_tokens_to_sample": 300,
        "temperature": 0.1,
        "top_p": 0.9,
    })
    
    modelId = 'anthropic.claude-v2'
    accept = 'application/json'
    contentType = 'application/json'
    
    # Invoke the Bedrock model
    response = bedrock.invoke_model(body=body, modelId=modelId, accept=accept, contentType=contentType)
    
    # Parse the response from Bedrock
    #response_body = json.loads(response['Body'].read().decode())
    response_body = json.loads(response.get("body").read())
    
    # Return the completion (recommendation) from the response
    return {
        'statusCode': 200,
        'body': json.dumps({"recommendation": response_body.get('completion')})
    }


